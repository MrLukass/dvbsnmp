/* 
 * File:   config.h
 * Author: lukas
 *
 * Created on January 18, 2015, 6:05 PM
 */

#ifndef CONFIG_H
#define	CONFIG_H

#define VERSION "1.0.1"
#define MAXDEVICECOUNT 8
#define OUTPUTXMLDOCUMENTPATH "/tmp/dvbinfoout.xml"


#endif	/* CONFIG_H */

