/* 
 * File:   SNMPHelper.h
 * Author: Lukas Zajac <zajac.ov@gmail.com>
 *
 * Created on February 25, 2015, 12:19 PM
 */

#ifndef SNMPHELPER_H
#define	SNMPHELPER_H

#ifdef	__cplusplus
extern "C" {
#endif

void cleanTableSet (netsnmp_table_data_set *table_set);


#ifdef	__cplusplus
}
#endif

#endif	/* SNMPHELPER_H */

